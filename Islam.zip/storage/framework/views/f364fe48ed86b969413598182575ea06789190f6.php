<div class="verification-error">
    <div class="verification-error__header">
        <div class="verification-error__header-i"> <img src="/assets/svg/verification/error.svg"></div>
        <div class="verification-error__header-t">Проверка прошла успешно</div>
    </div>
    <div class="verification-error__content">
        <div class="verification-error__content-t">Проверьте правильность написания номера сертификата или других данных для поиска. </div>
        <div class="verification-error__content-d">
            Если в итоге вы не смогли найти свой сертификат, то:<br>1. Обратитесь к своему рекомендателю, чтобы уточнить добавлен ли ваш платеж<br>2. Если рекомендателя нет, то напишите нам в поддержку на сайте позвоните по номеру  8 800 453 83 04</div>
        <div class="verification-error__content-buttons"> <a class="verification-error__content-button" href="/">Обратиться к рекомендателю</a><a class="verification-error__content-button" href="/">Написать в поддержку</a></div>
    </div>
</div>
<?php /**PATH D:\OpenServer\domains\Islam\resources\views/ajax/verification/error.blade.php ENDPATH**/ ?>